# MNB ScraperKit V4.0.1 - install a preset pack
php "$PSScriptRoot/../bin/mnb-scraper" preset:install commerce-gov-pack --output-dir=presets/commerce-gov
