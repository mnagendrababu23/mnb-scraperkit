@echo off
REM MNB ScraperKit V4.0.1 - create a starter project template
php "%~dp0..\bin\mnb-scraper" template:create seo-audit --output-dir=projects\seo-audit --name=seo-audit
